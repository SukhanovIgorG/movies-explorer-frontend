exports.startMovies = [
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
];

exports.savedMovies = [
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
  {
    country: "usa",
    director: "mister",
    duration: "100",
    year: "2008",
    description: "tenet",
    image:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    trailerLink:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    thumbnail:
      "https://www.politnavigator.net/wp-content/uploads/2020/09/main_2x.jpg",
    nameRU: "довод2",
    nameEN: "tenet2",
  },
];
