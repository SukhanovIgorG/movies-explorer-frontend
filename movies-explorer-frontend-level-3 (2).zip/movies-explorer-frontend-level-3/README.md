# movies-explorer-frontend

Публичная ссылка - https://nomoremovies.nomoredomains.sbs

Макет - https://www.figma.com/file/fo1gBu1qrGqiGHnNsRPx0I/Diploma-(Copy)?node-id=932%3A3908

Pull requests level-3 - https://github.com/SukhanovIgorG/movies-explorer-frontend/pull/2
