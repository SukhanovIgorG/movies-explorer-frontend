exports.regEmail = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/ ;
exports.regName = /^[А-ЯA-Zё -]+$/i ;
